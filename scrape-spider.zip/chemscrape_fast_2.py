import sys

import undetected_chromedriver as uc
from selenium import webdriver
from selenium.common import TimeoutException
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager

options = webdriver.ChromeOptions()
chrome_path = ChromeDriverManager().install()
chrome_service = Service(chrome_path)

print("Creating driver")
driver = uc.Chrome(options=options, service=chrome_service)
print("Driver created")

with open("links_record.txt") as file:
    links = [line.rstrip() for line in file]

links = links[int(sys.argv[1]):]

driver.implicitly_wait(5)

wait_time = 10
wait = WebDriverWait(driver, wait_time)

for link in links:
    if link == "/Chemical-Structure.21111803.html":
        # skip
        continue

    full_link = "http://www.chemspider.com" + link
    print("Visiting", full_link)
    driver.get(full_link)

    try:
        # Wait for the <a> tag with title "RN" to be present and visible
        a_element = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, 'a[title="RN"]')))

        # Extract the href attribute of the <a> tag
        href = a_element.get_attribute("href")

        # Process the href as needed
        print("Found RN link:", href)

        actual_RN = href.split("term=%22")[1].split("%22")[0]

        with open("rns.txt", "a") as myfile:
            myfile.write(actual_RN + "\n")

    except TimeoutException:
        with open("errors.txt", "a") as myfile:
            myfile.write(full_link + "\n")

        print("Element with title 'RN' not found within {} seconds".format(wait_time))

driver.quit()
